package com.capgemini.dto;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



@Entity
@Table(name = "TRANSACTION_DETAILS")
public class TransactionDTO implements Serializable 
{	
	private static final long serialVersionUID = 1L;
	
	/*public AccountsDTO getAccountsDTO() {
		return accountsDTO;
	}
	public void setAccountsDTO(AccountsDTO accountsDTO) {
		this.accountsDTO = accountsDTO;
	}*/

	@Id
	@Column(name="transaction_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long transId;
	
	@Column(name="transaction_description")
	private String transDesc;
	
	@Column(name="transaction_amount")
	private double transAmount;
	

	@Column(name="transaction_date")
	private Date date;
	
	@Column(name="account_number")
	private String accountNum;
	public long getTransId() {
		return transId;
	}
	
	//@ManyToOne
	//private AccountsDTO accountsDTO;
	
	public void setTransId(long transId) {
		this.transId = transId;
	}
	public String getTransDesc() {
		return transDesc;
	}
	public void setTransDesc(String transDesc) {
		this.transDesc = transDesc;
	}
	public double getTransAmount() {
		return transAmount;
	}
	public void setTransAmount(double transAmount) {
		this.transAmount = transAmount;
	}
	
	
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}
	public TransactionDTO() {
		super();
	}	
	
	
}
